#include "utils.h"

// Add helper function implementations here
